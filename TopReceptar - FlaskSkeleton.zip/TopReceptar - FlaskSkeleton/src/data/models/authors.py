from flask_login import UserMixin
from sqlalchemy.schema import Column
from sqlalchemy.types import Boolean, Integer, String, Enum

from ..database import db
from ..mixins import CRUDModel
from ..util import generate_random_token
from ...settings import app_config
from ...extensions import bcrypt

class Authors(CRUDModel, UserMixin):
    __tablename__ = 'authors'
    __table_args__ = {'sqlite_autoincrement': True}
    id = Column(Integer, primary_key=True)
    name = Column(String(64), nullable=False, unique=False, index=True)
    rank = Column(String(64), nullable=False, unique=True, index=True)
    sex = Column(Enum('muz','zena', name='sexTypes'))

    # Use custom constructor
    # pylint: disable=W0231
    def __init__(self, **kwargs):
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    @staticmethod
    def find_by_email(name):
        return db.session.query(Authors).filter_by(name=name).scalar()

    # pylint: disable=R0201

